class EventsWorldData extends SurvivorMissions
{
	const string EWD_MAP_NAME = "banov";
	const string EWD_SCRIPT_VERSION = "0.85";
	static ref array<string> MissionEvents = new array<string>;
	static ref array<vector> MissionPositions = new array<vector>;
	static ref array<Object> ObjectList = new array<Object>; 
	static ref array<CargoBase> ObjectCargoList = new array<CargoBase>;
	
	void EventsWorldData()
	{
		//Mission event																		//Mission position (absolute or BuildingPos)
		//0
		MissionEvents.Insert("Apartment Velke_Drzkovce Central TenSmall_1");				MissionPositions.Insert("534.990906 236.949982 2964.322021");
		MissionEvents.Insert("Apartment Motesice North TenSmall_1");						MissionPositions.Insert("746.752380 274.851532 13258.923828");
		MissionEvents.Insert("Apartment Motesice North TenSmall_2");						MissionPositions.Insert("727.702759 274.818665 13272.088867");
		MissionEvents.Insert("Apartment Bobot SE TenSmall_1");								MissionPositions.Insert("1525.667114 240.964035 10184.491211");
		MissionEvents.Insert("Apartment Bobot SE TenSmall_2");								MissionPositions.Insert("1533.754150 242.569839 10403.247070");
		MissionEvents.Insert("Apartment Ruskovce NE TenSmall_1");							MissionPositions.Insert("1608.85 228.0720 4684.9");	
		MissionEvents.Insert("Apartment Dezerice SW TenSmall_1");							MissionPositions.Insert("2777.743408 219.098419 5830.904785");
		MissionEvents.Insert("Apartment Dezerice SW TenSmall_2");							MissionPositions.Insert("2823.611084 219.501617 5790.726563");
		MissionEvents.Insert("Apartment Dvorec North TenSmall_1");							MissionPositions.Insert("3727.843506 223.329285 701.590332");
		MissionEvents.Insert("Apartment Krasna_Ves NW TenSmall_1");							MissionPositions.Insert("3883.912109 280.543091 13895.021484");
		MissionEvents.Insert("Apartment Pudluzany South TenSmall_1");						MissionPositions.Insert("4935.430 222.865 6345.73");
		MissionEvents.Insert("Apartment Pudluzany South TenSmall_2");						MissionPositions.Insert("4923.23 222.348 6385.48");	
		MissionEvents.Insert("Apartment Pudluzany South TenSmall_3");						MissionPositions.Insert("4954.59375 222.875137 6407.509");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_1");					MissionPositions.Insert("5324.237305 205.801025 2832.118896");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_2");					MissionPositions.Insert("5388.164063 205.311829 2550.874512");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_3");					MissionPositions.Insert("5426.594238 205.859558 2582.434814");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_4");					MissionPositions.Insert("5401.601074 205.287781 2532.704346");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_5");					MissionPositions.Insert("5517.385254 208.581543 2697.094238");	
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_6");					MissionPositions.Insert("5576.835449 205.770462 1857.621094");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_7");					MissionPositions.Insert("5569.142578 208.342743 2623.185791");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_8");					MissionPositions.Insert("5531.639160 208.469086 2679.651123");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_9");					MissionPositions.Insert("5540.461426 208.391724 2657.811279");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_10");					MissionPositions.Insert("5554.765625 208.410400 2640.426025");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_11");					MissionPositions.Insert("5565.619629 209.259186 2740.719727");	
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_12");					MissionPositions.Insert("5608.405273 206.046265 1766.877319");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_13");					MissionPositions.Insert("5636.556641 206.395004 1798.332886");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_14");					MissionPositions.Insert("5598.112305 206.172134 1796.071777");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_15");					MissionPositions.Insert("5629.874023 206.364243 1819.888306");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_16");					MissionPositions.Insert("5587.993652 206.090179 1824.137939");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_17");					MissionPositions.Insert("5623.445801 206.178055 1841.475464");	
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_18");					MissionPositions.Insert("5616.842773 206.144196 1862.891724");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_19");					MissionPositions.Insert("5583.614258 208.388657 2605.942871");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_20");					MissionPositions.Insert("5619.515137 208.315735 2727.348877");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_21");					MissionPositions.Insert("5584.293945 208.950470 2728.072754");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_22");					MissionPositions.Insert("5639.060059 208.333008 2738.570313");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SW TenSmall_23");					MissionPositions.Insert("5698.010742 206.109634 1405.666870");	
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SW TenSmall_24");					MissionPositions.Insert("5692.087402 206.731842 1426.895630");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SW TenSmall_25");					MissionPositions.Insert("5681.189453 206.279419 1483.346191");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SW TenSmall_26");					MissionPositions.Insert("5686.157227 206.586670 1448.843140");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_27");					MissionPositions.Insert("5657.315430 206.252701 1614.984741");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_28");					MissionPositions.Insert("5651.713867 206.241135 1636.838501");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_29");					MissionPositions.Insert("5680.374512 206.253326 1705.635376");	
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_30");					MissionPositions.Insert("5687.960938 206.268982 1684.648193");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou West TenSmall_31");					MissionPositions.Insert("5643.027832 206.385498 1776.808472");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_32");					MissionPositions.Insert("5658.491211 208.525909 2749.688965");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_33");					MissionPositions.Insert("5677.873535 208.887070 2761.057861");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_34");					MissionPositions.Insert("5649.396973 211.954254 2877.814209");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou North TenSmall_35");					MissionPositions.Insert("5676.791016 211.954865 2841.942871");	
		MissionEvents.Insert("Apartment Slatina_nad_Bebravou NE TenSmall_1");				MissionPositions.Insert("6735.153320 297.490295 13833.880859");
		MissionEvents.Insert("Apartment Slatina_nad_Bebravou NE TenSmall_2");				MissionPositions.Insert("6791.106445 297.194946 13821.633789");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SE TenSmall_1");					MissionPositions.Insert("7387.204102 237.359833 1553.575684");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou SE TenSmall_2");					MissionPositions.Insert("7404.163086 237.360352 1568.414917");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou NE TenSmall_3");					MissionPositions.Insert("6310.47 230.46 2266.62");
		MissionEvents.Insert("Apartment Banovce_nad_Bebravou NE TenSmall_4");					MissionPositions.Insert("6209.43 224.658 2300.15");	
		MissionEvents.Insert("Apartment Miezgoce West TenSmall_1");							MissionPositions.Insert("9323.177734 244.225082 1671.089111");
		MissionEvents.Insert("Apartment Uhrovec West TenSmall_1");							MissionPositions.Insert("11457.351563 261.350952 4099.387695");
		MissionEvents.Insert("Apartment Uhrovec West TenSmall_2");							MissionPositions.Insert("11413.236328 261.350922 4165.156250");
		MissionEvents.Insert("Apartment Uhrovec West TenSmall_3");							MissionPositions.Insert("11443.610352 261.355835 4151.474609");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_4");							MissionPositions.Insert("11513.776367 274.933624 4391.702637");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_5");							MissionPositions.Insert("11637.491211 258.513733 4315.448730");	
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_6");							MissionPositions.Insert("11602.490234 261.322662 4305.566406");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_7");							MissionPositions.Insert("11672.914063 254.619141 4232.277832");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_8");							MissionPositions.Insert("11689.086914 254.194580 4293.059570");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_9");							MissionPositions.Insert("11684.523438 254.201447 4271.008789");
		MissionEvents.Insert("Apartment Uhrovec NW TenSmall_10");							MissionPositions.Insert("11693.418945 254.466049 4315.147461");
		MissionEvents.Insert("Apartment Uhrovec North TenSmall_11");							MissionPositions.Insert("11735.888672 252.298767 4333.825195");	
		MissionEvents.Insert("Apartment Uhrovec North TenSmall_12");							MissionPositions.Insert("11735.914063 252.328873 4356.309082");
		MissionEvents.Insert("Apartment Uhrovec North TenSmall_13");							MissionPositions.Insert("11736.032227 252.276413 4378.865234");
		MissionEvents.Insert("Apartment Uhrovec North TenSmall_14");							MissionPositions.Insert("11900.668945 250.642899 4204.313965");
		MissionEvents.Insert("Apartment Uhrovec North TenSmall_15");							MissionPositions.Insert("11893.370117 250.754593 4423.681152");
		MissionEvents.Insert("Apartment Latkovce South TenSmall_1");						MissionPositions.Insert("13039.443359 311.149200 350.221344");
		MissionEvents.Insert("Apartment Latkovce Central TenSmall_2");						MissionPositions.Insert("13080.560547 312.859955 525.640076");			
		//72  //72 Apartment Missions
		MissionEvents.Insert("BearHunt Motesice East Bobot");								MissionPositions.Insert("2395.74 364 13731.3");
		MissionEvents.Insert("BearHunt Motesice North Bobot");								MissionPositions.Insert("851.2 279 14916.5");
		MissionEvents.Insert("BearHunt Bobot East Motesice");								MissionPositions.Insert("2567.94 287 10624.6");
		MissionEvents.Insert("BearHunt Bobot SE Motesice");									MissionPositions.Insert("2334.15 260 10047.8");
		MissionEvents.Insert("BearHunt Bobot SE Motesice");									MissionPositions.Insert("809.875 292.5 10247.2");
		MissionEvents.Insert("BearHunt Kopec West Slatina_nad_Bebravou");					MissionPositions.Insert("5953.71 312.5 12330.6");
		MissionEvents.Insert("BearHunt Kopec NE Slatina_nad_Bebravou");						MissionPositions.Insert("7698.79 434 12608.9");
		MissionEvents.Insert("BearHunt Asgard_Castle North Slatina_nad_Bebravou");			MissionPositions.Insert("8982.76 441.7 13466.4");
		MissionEvents.Insert("BearHunt Ceremor_Wooden_Pile North Slatina_nad_Bebravou");	MissionPositions.Insert("6542.77 521 15301.8");	
		MissionEvents.Insert("BearHunt Latkovce NW Uhrovec");								MissionPositions.Insert("12711.4 354 1345.35");
		MissionEvents.Insert("BearHunt Miezgoce North Uhrovec");							MissionPositions.Insert("10022.6 309 2398.57");
		MissionEvents.Insert("BearHunt Dubnicka East Uhrovec");								MissionPositions.Insert("9968.36 304.5 6662.87");
		MissionEvents.Insert("BearHunt Zitna_Radisa West Uhrovec");							MissionPositions.Insert("11902.4 293.5 7035.76");
		MissionEvents.Insert("BearHunt Miezgoce South Banovce_nad_Bebravou");					MissionPositions.Insert("9864.73 287 423.318");
		MissionEvents.Insert("BearHunt Dvorec West Banovce_nad_Bebravou");						MissionPositions.Insert("2490.54 228.5 309.637");	
		MissionEvents.Insert("BearHunt Prusy SE Banovce_nad_Bebravou");							MissionPositions.Insert("7142.52 253 4080.29");
		MissionEvents.Insert("BearHunt Prusy NE Banovce_nad_Bebravou");							MissionPositions.Insert("7055.64 278.7 6493.5");
		MissionEvents.Insert("BearHunt Prusy North Banovce_nad_Bebravou");						MissionPositions.Insert("6319.21 238.5 6674.74");
		MissionEvents.Insert("BearHunt Dezerice SE Banovce_nad_Bebravou");						MissionPositions.Insert("3896.47 241 5623.49");
		MissionEvents.Insert("BearHunt Ruskovce East Banovce_nad_Bebravou");						MissionPositions.Insert("2593.37 228.7 3863.49");		
		//92	//20 BearHunt missions	
		MissionEvents.Insert("Camp Motesice SW MedTent_1");									MissionPositions.Insert("212.192 269.233 12587.1");
		MissionEvents.Insert("Camp Motesice NW MedTent_1");									MissionPositions.Insert("291.294 327.14 14103.3");
		MissionEvents.Insert("Camp Bobot East MedTent_1");									MissionPositions.Insert("2444.55 272.687 10610.5");
		MissionEvents.Insert("Camp Ruskovce NW MedTent_1");									MissionPositions.Insert("816.092 242.389 4851.14");
		MissionEvents.Insert("Camp Velke_Drzkovce South MedTent_1");						MissionPositions.Insert("209.203 270.552 1756.66");
		MissionEvents.Insert("Camp Sliezska_Osada South MedTent_1");						MissionPositions.Insert("2621.32 215.087 1480.24");
		MissionEvents.Insert("Camp Dezerice NE MedTent_1");									MissionPositions.Insert("3340.76 238.278 6495.06");
		MissionEvents.Insert("Camp Horne_Ozorovce NW MedTent_1");							MissionPositions.Insert("3912.38 209.978 3960.31");
		MissionEvents.Insert("Camp Banovce_nad_Bebravou SE MedTent_1");							MissionPositions.Insert("7149.4 276.819 530.588");
		MissionEvents.Insert("Camp Horne_Nastice North MedTent_1");							MissionPositions.Insert("9255.61 243.862 4241.58");
		MissionEvents.Insert("Camp Lutov NW MedTent_1");									MissionPositions.Insert("7223.27 308.612 8150.07");
		MissionEvents.Insert("Camp Timoradza North MedTent_1");								MissionPositions.Insert("4638.55 233.167 11248.6");
		MissionEvents.Insert("Camp Krasna_Ves SW MedTent_1");								MissionPositions.Insert("3815.85 280.03 13676");
		MissionEvents.Insert("Camp Slatina_nad_Bebravou North MedTent_1");					MissionPositions.Insert("6457.76 313.925 14353.9");
		MissionEvents.Insert("Camp Trebichava SW MedTent_1");								MissionPositions.Insert("8657.81 474.237 12024.5");	
		MissionEvents.Insert("Camp Ksinna East MedTent_1");									MissionPositions.Insert("13134 367.629 10938");
		MissionEvents.Insert("Camp Zitna_Radisa SE MedTent_1");								MissionPositions.Insert("12390.6 300.324 6724.16");
		MissionEvents.Insert("Camp Uhrovec NW MedTent_1");									MissionPositions.Insert("11083.4 268.653 4539.22");
		MissionEvents.Insert("Camp Miezgoce South MedTent_1");								MissionPositions.Insert("9751.65 292.641 625.605");
		MissionEvents.Insert("Camp Dubnicka North MedTent_1");								MissionPositions.Insert("9055.31 305.977 7348.38");			
		//112  // 20 Camp Missions
		MissionEvents.Insert("CityMall Banovce_nad_Bebravou NW Bobot");							MissionPositions.Insert("5543.156250 198.211411 2540.260010");
		MissionEvents.Insert("CityMall Banovce_nad_Bebravou West Slatina_nad_Bebravou");			MissionPositions.Insert("5680.520996 198.195404 1931.062744");
		MissionEvents.Insert("CityMall Uhrovec central Biskupice");							MissionPositions.Insert("11703.058594 249.140533 4193.973145");		
		//115 // 3 city mall missions. Give more time for Citymall missions
		MissionEvents.Insert("FreePigs Ruskovce NW Bobot");									MissionPositions.Insert("249.620895 232.231857 5088.640137");
		MissionEvents.Insert("FreePigs Velke_Drzkovce NW Bobot");							MissionPositions.Insert("348.440826 232.648956 3045.574707");
		MissionEvents.Insert("FreePigs Farma_Pod_rohom Central Ruskovce");					MissionPositions.Insert("1048.26 240.07 280.35");
		MissionEvents.Insert("FreePigs Bobot South Ruskovce");								MissionPositions.Insert("1190.31 236.555969 10014.320898");
		MissionEvents.Insert("FreePigs Bobot South Ruskovce");								MissionPositions.Insert("1214.17 236.555969 10021.5");
		MissionEvents.Insert("FreePigs Ruskovce South Bobot");								MissionPositions.Insert("1358.269287 225.383530 3769.707275");
		MissionEvents.Insert("FreePigs Ruskovce South Bobot");								MissionPositions.Insert("1372.240845 225.294083 3809.067871");
		MissionEvents.Insert("FreePigs Ruskovce South Bobot");								MissionPositions.Insert("1405.603760 225.293930 3775.724121");
		MissionEvents.Insert("FreePigs Hornany North Velke_Drzkovce");						MissionPositions.Insert("1559.428223 220.403076 8003.179199");
		MissionEvents.Insert("FreePigs Hornany North Velke_Drzkovce");						MissionPositions.Insert("1546.304199 220.460968 8108.617676");
		MissionEvents.Insert("FreePigs Hornany North Velke_Drzkovce");						MissionPositions.Insert("1602.635376 220.415817 8089.548828");
		MissionEvents.Insert("FreePigs Bobot South Velke_Drzkovce");						MissionPositions.Insert("1805.35 233.525 9685.86");
		MissionEvents.Insert("FreePigs Bobot South Velke_Drzkovce");						MissionPositions.Insert("1805.35 233.525 9685.86");
		MissionEvents.Insert("FreePigs Hornany East Velke_Drzkovce");						MissionPositions.Insert("1941.913330 222.555130 7822.037598");
		MissionEvents.Insert("FreePigs Hornany East Velke_Drzkovce");						MissionPositions.Insert("1964.862061 222.455948 7834.614746");
		MissionEvents.Insert("FreePigs Sliezska_Osada NW Bobot");							MissionPositions.Insert("2042.348633 226.465958 2475.617188");
		MissionEvents.Insert("FreePigs Dvorec NE Ruskovce");								MissionPositions.Insert("3746.1813 209.195770 1019.08");
		MissionEvents.Insert("FreePigs Dvorec NE Ruskovce");								MissionPositions.Insert("3720.63 209.231052 911.87046");
		MissionEvents.Insert("FreePigs Timoradza SW Bobot");								MissionPositions.Insert("4402.974121 241.757446 10821.993164");	
		MissionEvents.Insert("FreePigs Biskupice South Velke_Drzkovce");					MissionPositions.Insert("5014.38477 200.545 230.9628");
		MissionEvents.Insert("FreePigs Podluzany South Ruskovce");							MissionPositions.Insert("5035.746094 215.880844 6257.629883");
		MissionEvents.Insert("FreePigs Biskupice South Velke_Drzkovce");					MissionPositions.Insert("5057.3555 200.5436 213.143");
		MissionEvents.Insert("FreePigs Podluzany South Ruskovce");							MissionPositions.Insert("5110.087402 217.044830 6230.705566");
		MissionEvents.Insert("FreePigs Podluzany South Ruskovce");							MissionPositions.Insert("5207.288086 219.882492 6323.107422");
		MissionEvents.Insert("FreePigs Timoradza South Bobot");								MissionPositions.Insert("5447.858887 240.253204 9174.159180");
		MissionEvents.Insert("FreePigs Prusy SW Ruskovce");									MissionPositions.Insert("5848.15 221.211 5028.34");
		MissionEvents.Insert("FreePigs Prusy SW Ruskovce");									MissionPositions.Insert("5867.64 221.212 5017.12");
		MissionEvents.Insert("FreePigs Prusy SW Ruskovce");									MissionPositions.Insert("5901.87 220.217 4986.23");
		MissionEvents.Insert("FreePigs Hvozdy Central Ceremor_Wooden_Pile");				MissionPositions.Insert("7385.285 292.50 13692.813");
		MissionEvents.Insert("FreePigs Hvozdy Central Ceremor_Wooden_Pile");				MissionPositions.Insert("7402.26 292.50 13701.5");
		MissionEvents.Insert("FreePigs Hvozdy Central Ceremor_Wooden_Pile");				MissionPositions.Insert("7385.285 292.50 13692.813");
		MissionEvents.Insert("FreePigs Horne_Nastice West Uhrovec");						MissionPositions.Insert("8404.48 206.756577 3001.513");	
		MissionEvents.Insert("FreePigs Miezgoce West Uhrovec");								MissionPositions.Insert("9222.676758 237.282654 1521.970703");
		MissionEvents.Insert("FreePigs Miezgoce West Uhrovec");								MissionPositions.Insert("9222.676758 237.282654 1521.970703");
		MissionEvents.Insert("FreePigs Uhrovec West Easthaven");							MissionPositions.Insert("11140.664063 235.073914 3631.162842");
		MissionEvents.Insert("FreePigs Uhrovec West Easthaven");							MissionPositions.Insert("11132.991211 235.075119 3659.875488");
		MissionEvents.Insert("FreePigs Uhrovec West Easthaven");							MissionPositions.Insert("11146.574219 235.073807 3605.922607");
		MissionEvents.Insert("FreePigs Ksinna SW Easthaven");								MissionPositions.Insert("11710.910156 370.914978 10623.171875");
		MissionEvents.Insert("FreePigs Ksinna SW Easthaven");								MissionPositions.Insert("11864.362305 364.527069 10538.208984");
		MissionEvents.Insert("FreePigs Zitna_Radisa Easthaven");							MissionPositions.Insert("12055.838867 263.765167 6361.956055");		
		//155	// 40 free pig missions. Give more time for Freepigs missions
		MissionEvents.Insert("Graveyard Lutov SE Stash_1");									MissionPositions.Insert("7985.61 247.046 7252.8");
		MissionEvents.Insert("Graveyard Podluzany North Stash_1");							MissionPositions.Insert("4952.35 218.715 7020.26");
		MissionEvents.Insert("Graveyard Motesice East Stash_1");							MissionPositions.Insert("1055.65 262.133 12981.6");
		MissionEvents.Insert("Graveyard Krasna_Ves North Stash_1");							MissionPositions.Insert("4137.03 269.711 14043.7");
		MissionEvents.Insert("Graveyard Slatina_nad_Bebravou North Stash_1");				MissionPositions.Insert("6412.58 298.25 14253.4");
		MissionEvents.Insert("Graveyard Ksinna SE Stash_1");								MissionPositions.Insert("12857.3 343.867 10616.7");
		MissionEvents.Insert("Graveyard Zitna_Radisa South Stash_1");						MissionPositions.Insert("12232.9 273.587 6615.82");
		MissionEvents.Insert("Graveyard Biskupice Central Stash_1");						MissionPositions.Insert("5014.76 193.019 504.073");		
		//163  // 8 Graveyard missions
		MissionEvents.Insert("Horde Ksinna Central Residential_1");							MissionPositions.Insert("12726.6 327.613 10980.4");
		MissionEvents.Insert("Horde Uhrovec NE Residential_1");								MissionPositions.Insert("11896.3 241.913 4342.5");
		MissionEvents.Insert("Horde Latkovce South Residential_1");							MissionPositions.Insert("13080.1 302.263 433.291");
		MissionEvents.Insert("Horde Miezgoce West Residential_1");							MissionPositions.Insert("9526.67 246.407 1674.66");
		MissionEvents.Insert("Horde Prusy North Residential_1");							MissionPositions.Insert("6234.17 219.389 6135.19");
		MissionEvents.Insert("Horde Lutov South Residential_1");							MissionPositions.Insert("7621.45 238.516 7321.91");
		MissionEvents.Insert("Horde Slatina_nad_Bebravou NW Residential_1");				MissionPositions.Insert("6384.31 289.493 13802.2");
		MissionEvents.Insert("Horde Krasna_Ves SE Residential_1");							MissionPositions.Insert("4436.75 253.661 13489.9");
		MissionEvents.Insert("Horde Timoradza NW Residential_1");							MissionPositions.Insert("4509.21 233.861 11175.5");
		MissionEvents.Insert("Horde Podluzany North Residential_1");						MissionPositions.Insert("4672.48 214.033 7289.31");
		MissionEvents.Insert("Horde Horne_Ozorovce North Residential_1");					MissionPositions.Insert("4261.69 201.84 3276.31");
		MissionEvents.Insert("Horde Banovce_nad_Bebravou SW Residential_1");				MissionPositions.Insert("6367.5 205.592 1500.76");
		MissionEvents.Insert("Horde Biskupice East Residential_1");							MissionPositions.Insert("5182.44 197.1 429.299");
		MissionEvents.Insert("Horde Ruskovce SW Residential_1");							MissionPositions.Insert("1162.38 219.289 3946.11");
		MissionEvents.Insert("Horde Velke_Drzkovce West Residential_1");					MissionPositions.Insert("378.509 225.467 2852.47");
		MissionEvents.Insert("Horde Dvorec South Residential_1");							MissionPositions.Insert("3673.48 215.496 393.924");
		MissionEvents.Insert("Horde Dezerice Central Residential_1");						MissionPositions.Insert("2925.72 213.522 6275.89");
		MissionEvents.Insert("Horde Bobot SW Residential_1");								MissionPositions.Insert("1248.5 234.755 10365");
		MissionEvents.Insert("Horde Dolne_Motesice Central Residential_1");					MissionPositions.Insert("324.688 253.833 11625.3");	
		MissionEvents.Insert("Horde Motesice Central Residential_1");						MissionPositions.Insert("880.787 261.433 12985.1");			
		//183  // 20 Horde Missions
		MissionEvents.Insert("PlaneCrash Military_Tisovik Central 317");					MissionPositions.Insert("11848.1 621.6 14861.5");
		MissionEvents.Insert("PlaneCrash Alica_Airport North 318");							MissionPositions.Insert("4883.84 206.395 5142.61");
		MissionEvents.Insert("PlaneCrash Slatina_nad_Bebravou NW 319");						MissionPositions.Insert("6063.04 281.907 14141.7");
		MissionEvents.Insert("PlaneCrash Ksinna NE 320");									MissionPositions.Insert("13587.4 363.992 11278.9");
		MissionEvents.Insert("PlaneCrash Zitna_Radisa West 321");							MissionPositions.Insert("10874.3 366.141 6820.6");
		MissionEvents.Insert("PlaneCrash Uhrovec SW 322");									MissionPositions.Insert("10589.7 234.051 3585.78");
		MissionEvents.Insert("PlaneCrash Hornany NE 323");									MissionPositions.Insert("3200.25 280.447 8733.29");
		MissionEvents.Insert("PlaneCrash Podluzany North 324");								MissionPositions.Insert("5099.96 228.278 7349.15");
		MissionEvents.Insert("PlaneCrash Motesice East 325");								MissionPositions.Insert("1390.1 290.591 12902.1");
		MissionEvents.Insert("PlaneCrash Hrabice_Airport East 326");						MissionPositions.Insert("3782.9 260.034 11812");		
		//193  // 10 PlaneCrash Missioins
		MissionEvents.Insert("Shrooms Horne_Ozorovce NW Banovce_nad_Bebravou");				MissionPositions.Insert("3962.8 212.077 3950.31");
		MissionEvents.Insert("Shrooms Sliezska_Osada North Banovce_nad_Bebravou");				MissionPositions.Insert("2395.11 240.956 2844.41");
		MissionEvents.Insert("Shrooms Prusy SW Banovce_nad_Bebravou");							MissionPositions.Insert("5531.46 213.664 5207.93");
		MissionEvents.Insert("Shrooms Lom_Podluzany SE OverGrown_Military");				MissionPositions.Insert("6346.54 324.894 8925.58");
		MissionEvents.Insert("Shrooms Kopec North OverGrown_Military");						MissionPositions.Insert("7166.88 301.322 13090.2");
		MissionEvents.Insert("Shrooms Asgard_Castle SE OverGrown_Military");				MissionPositions.Insert("9209.92 350.506 12700.1");
		MissionEvents.Insert("Shrooms Ksinna West OverGrown_Military");						MissionPositions.Insert("12074.9 360.001 10946.2");
		MissionEvents.Insert("Shrooms Lutov SE OverGrown_Military");						MissionPositions.Insert("8344.61 287.534 7151.06");
		MissionEvents.Insert("Shrooms Banovce_nad_Bebravou SE Banovce_nad_Bebravou");		MissionPositions.Insert("7495.58 308.716 415.95");
		MissionEvents.Insert("Shrooms Biskupice NW Banovce_nad_Bebravou");					MissionPositions.Insert("4597.67 192.147 623.918");
		MissionEvents.Insert("Shrooms Dvorec West Banovce_nad_Bebravou");					MissionPositions.Insert("3446.06 235.789 623.247");
		MissionEvents.Insert("Shrooms Horne_Nastice South Banovce_nad_Bebravou");			MissionPositions.Insert("8998.89 209.541 3039.84");
		MissionEvents.Insert("Shrooms Miezgoce SE Banovce_nad_Bebravou");					MissionPositions.Insert("10365.2 304.964 1137.82");
		MissionEvents.Insert("Shrooms Timoradza SW Hrabice_Airport");						MissionPositions.Insert("4499.51 233.622 10901.1");		
		MissionEvents.Insert("Shrooms Bobot South Hrabice_Airport");						MissionPositions.Insert("1385.14 232.244 9949.38");
		MissionEvents.Insert("Shrooms Motesice South Hrabice_Airport");						MissionPositions.Insert("624.81 250.329 12231.2");
		MissionEvents.Insert("Shrooms Krasna_Ves North Hrabice_Airport");					MissionPositions.Insert("9230.02 258.7 14306.5");
		MissionEvents.Insert("Shrooms Krasna_Ves West Hrabice_Airport");					MissionPositions.Insert("3217.06 296.655 13920.3");		
		//211  //18 Shroom Missions
		MissionEvents.Insert("Transport Motesice NW Banovce_nad_Bebravou");						MissionPositions.Insert("711.126160 267.405151 13281.381836");
		MissionEvents.Insert("Transport Ruskovce South Banovce_nad_Bebravou");					MissionPositions.Insert("1222.306152 221.558929 3858.055420");
		MissionEvents.Insert("Transport Bobot Central Banovce_nad_Bebravou");					MissionPositions.Insert("1238.928345 238.748489 10640.359375");
		MissionEvents.Insert("Transport Bobot North Banovce_nad_Bebravou");						MissionPositions.Insert("1348.467163 238.668259 10777.162109");
		MissionEvents.Insert("Transport Sliezska_Osada NW Banovce_nad_Bebravou");				MissionPositions.Insert("1806.027100 225.442230 2472.400146");
		MissionEvents.Insert("Transport Hrabice_Airport NE Banovce_nad_Bebravou");				MissionPositions.Insert("2114.84 270.393026 11938.45");
		MissionEvents.Insert("Transport Hrabice_Airport NE Banovce_nad_Bebravou");				MissionPositions.Insert("2114.84 270.393026 11938.45");
		MissionEvents.Insert("Transport Dezerice Central Banovce_nad_Bebravou");					MissionPositions.Insert("2874.193848 212.388763 6142.631348");
		MissionEvents.Insert("Transport Dezerice South Banovce_nad_Bebravou");					MissionPositions.Insert("3157.963867 214.766693 5976.678711");
		MissionEvents.Insert("Transport Dezerice South Banovce_nad_Bebravou");					MissionPositions.Insert("3169.957275 214.721252 5986.001465");	
		MissionEvents.Insert("Transport Timoradza North Banovce_nad_Bebravou");					MissionPositions.Insert("4181.658691 234.758469 11428.000977");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("4939.97 214.61 6367.23926");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("5063.34 214.84 6370.370898");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("5059.08 214.83 6400.438");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("5063.339844 214.849350 6370.312500");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("5059.079102 214.833023 6400.433594");
		MissionEvents.Insert("Transport Pudluzany South Banovce_nad_Bebravou");					MissionPositions.Insert("5061.187988 214.869217 6385.406250");
		MissionEvents.Insert("Transport OverGrown_Military Central Banovce_nad_Bebravou");		MissionPositions.Insert("8131.596191 548.862854 9795.903320");
		MissionEvents.Insert("Transport OverGrown_Military Central Banovce_nad_Bebravou");		MissionPositions.Insert("8188.729004 548.862854 9669.259766");
		MissionEvents.Insert("Transport OverGrown_Military Central Banovce_nad_Bebravou");		MissionPositions.Insert("8178.243164 548.862854 9687.137695");
		MissionEvents.Insert("Transport OverGrown_Military NE Banovce_nad_Bebravou");			MissionPositions.Insert("8298.15 548.862854 9959.58");
		MissionEvents.Insert("Transport Dubnicka NE Banovce_nad_Bebravou");						MissionPositions.Insert("9314.727539 247.190720 6688.323730");
		MissionEvents.Insert("Transport Radio_North_Exile NE Banovce_nad_Bebravou");				MissionPositions.Insert("10971.690430 597.250183 12686.641602");
		MissionEvents.Insert("Transport Radio_North_Exile NE Banovce_nad_Bebravou");				MissionPositions.Insert("10996.308594 597.250183 12669.340820");
		MissionEvents.Insert("Transport Radio_North_Exile NE Banovce_nad_Bebravou");				MissionPositions.Insert("10983.934570 597.250183 12678.021484");
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11706.504883 244.449539 4252.023926");
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11721.381836 244.272858 4300.760742");	
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11715.220703 244.336746 4265.044922");
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11721.380859 244.267227 4285.651855");
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11795.208984 246.453857 4560.773926");
		MissionEvents.Insert("Transport Uhrovec Central Banovce_nad_Bebravou");					MissionPositions.Insert("11793.836914 246.464218 4576.065918");
		MissionEvents.Insert("Transport Uhrovec East Banovce_nad_Bebravou");						MissionPositions.Insert("11879.361328 242.604874 4219.322754");
		MissionEvents.Insert("Transport Uhrovec East Banovce_nad_Bebravou");						MissionPositions.Insert("11864.865234 242.579407 4238.754395");
		MissionEvents.Insert("Transport Uhrovec East Banovce_nad_Bebravou");						MissionPositions.Insert("11880.164063 242.578262 4238.640137");
		MissionEvents.Insert("Transport Uhrovec East Banovce_nad_Bebravou");						MissionPositions.Insert("11895.332031 242.594299 4238.605957");
		MissionEvents.Insert("Transport Uhrovec East Banovce_nad_Bebravou");						MissionPositions.Insert("11925.794922 242.875809 4311.182617");
		MissionEvents.Insert("Transport Latkovce NW Banovce_nad_Bebravou");						MissionPositions.Insert("12903.084961 315.543549 606.582214");			
		//247  // 36 Transport missions. Give more time for Transport missions.
					
		// ***Add new mission events below this line	
		//example: MissionEvents.Insert("MyNewMissionType Location LocationDir additionalParam");	MissionPositions.Insert("6869.6 350.3 10277.7");
	}
	
	static void BuildInstance()
	{
		//check for mission type to instantiate mission
		if ( m_MissionType == "Apartment" )		m_MissionInstance = new ApartmentMission();
		if ( m_MissionType == "BearHunt" )		m_MissionInstance = new BearHuntMission();	
		if ( m_MissionType == "Camp" )			m_MissionInstance = new CampMission();
		if ( m_MissionType == "CityMall" )		m_MissionInstance = new CityMallMission();
		if ( m_MissionType == "FreePigs" )		m_MissionInstance = new FreePigsMission();
		if ( m_MissionType == "Graveyard" )		m_MissionInstance = new GraveyardMission();
		if ( m_MissionType == "Horde" )			m_MissionInstance = new HordeMission();
		if ( m_MissionType == "PlaneCrash" )	m_MissionInstance = new PlaneCrashMission();			
		if ( m_MissionType == "Shrooms" )		m_MissionInstance = new ShroomsMission();
		if ( m_MissionType == "Transport" )		m_MissionInstance = new TransportMission();
		// ***Add new mission types below this line when new mission events were defined 
		//example: if ( ( m_MissionType == "MyNewMissionType" )		m_MissionInstance = new MyNewMission();
	}
		
	static bool GetBuildingsAtLoc( string MBuilding, string MLocation, out array<vector> BuildingPosList )
	{
		//Get positions of a unique mission building by the town/village name
		BuildingPosList = new array<vector>;
		
		if ( MBuilding == "Land_City_Hospital")
		{
			if ( MLocation == "Hrabice_Airport") 			BuildingPosList.Insert("1884.73 276.3 11613.8");
			else if ( MLocation == "Banovce_nad_Bebravou")	BuildingPosList.Insert("6051.450195 221.410583 1656.371582");
			else if ( MLocation == "Banovce_nad_Bebravou") 		BuildingPosList.Insert("6330.763184 226.631943 2113.030762");
			else if ( MLocation == "OverGrown_Military") 	BuildingPosList.Insert("8350.83 554.78710 9991.1609");
			else return false;			//No match by location						
		}
		else if ( MBuilding == "Land_FuelStation_Build")
		{
			if ( MLocation == "Banovce_nad_Bebravou")			BuildingPosList.Insert("5465.608398 197.980072 2468.639160");
			else return false;			//No match by location
		}
		else if ( MBuilding == "Land_Village_PoliceStation")
		{
			if ( MLocation == "Bobot")						BuildingPosList.Insert("1216.645874 244.110107 10649.116211");
			else if ( MLocation == "Biskupice")				BuildingPosList.Insert("4929.449219 199.827362 511.889374");
			else if ( MLocation == "Slatina_nad_Bebravou")	BuildingPosList.Insert("6420.723633 289.758209 13893.977539");
			else return false;			//No match by location
		}
		else if ( MBuilding == "Land_Misc_TrailRoof_Small")
		{
			if ( MLocation == "Velke_Drzkovce")				BuildingPosList.Insert("583.696777 232.819702 3019.672363");
			else if ( MLocation == "Hotel_Delta")			BuildingPosList.Insert("630.552551 249.255310 7208.463379");
			else if ( MLocation == "Ruskovce")				BuildingPosList.Insert("1118.828125 222.790039 4168.710449");
			else if ( MLocation == "Bobot")					BuildingPosList.Insert("1534.348389 235.777115 10492.192383");
			else if ( MLocation == "Biskupice")				BuildingPosList.Insert("5024.604980 194.914932 409.606384");
			else if ( MLocation == "Ceremor_Wooden_Pile")	BuildingPosList.Insert("6366.261719 481.586761 15063.109375");
			else if ( MLocation == "Uhrovec")				BuildingPosList.Insert("11922.734375 252.468689 3210.601074");
			else if ( MLocation == "Easthaven")				BuildingPosList.Insert("14554.000000 540.318726 9668.780273");
			else return false;			//No match by location
		}		
		else if ( MBuilding == "Land_City_School")
		{
			if ( MLocation == "Motesice")					BuildingPosList.Insert("684.484863 265.750366 12984.131836");
			else if ( MLocation == "Bobot")					BuildingPosList.Insert("1493.103882 241.809906 10541.159180");
			else if ( MLocation == "Banovce_nad_Bebravou")		BuildingPosList.Insert("5449.335938 203.101028 2871.658447");
			else if ( MLocation == "Banovce_nad_Bebravou")		BuildingPosList.Insert("5683.648926 202.917572 2662.528320");
			else if ( MLocation == "Banovce_nad_Bebravou")	BuildingPosList.Insert("6206.204102 211.049622 1013.855103");
			else if ( MLocation == "Banovce_nad_Bebravou")	BuildingPosList.Insert("6194.844727 220.164078 1827.253784");
			else if ( MLocation == "Banovce_nad_Bebravou")		BuildingPosList.Insert("6407.578613 227.704041 2175.014160");
			else if ( MLocation == "Slatina_nad_Bebravou")	BuildingPosList.Insert("6643.898926 291.029358 13756.055664");
			else if ( MLocation == "Uhrovec")				BuildingPosList.Insert("11522.007813 256.815308 4118.150391");			
			else return false;			//No match by location	
		}
		else return false;		//No match by building type. Keep this line after last building check!
		
		return true;
	}
	
	static void CheckEWD()
	{
		int ErrorCount = 0;
		
		for ( int i=0; i < MissionPositions.Count(); i++)
		{
			string Description[4];
			string EventName = MissionEvents.Get(i);
			vector Position = MissionPositions.Get(i);
			
			EventName.ParseString( Description );
			string Type = Description[0];
			string Location = Description[1];
			string LocDirection = Description[2];
			string Secondary = Description[3];
			
			//check for primary MissionBuilding, exclude missions with no primary MissionBuilding 
			if ( !PrimaryMissionCHK( Type, Position, i )) 
			{
				ErrorCount++;
				Print("[SEM] EWD Check additional mission Info : Type: "+ Type +" mission, location: "+ LocDirection +" of "+ Location +", Secondary mission:"+ Secondary );
			}
			//check for secondary MissionBuilding, exclude missions with no secondary MissionBuilding
			else if ( !SecondaryMissionCHK( Type, Secondary, i )) 
			{
				ErrorCount++;
				Print("[SEM] EWD Check additional mission Info : Type: "+ Type +" mission, location: "+ LocDirection +" of "+ Location +", Secondary mission:"+ Secondary );
			}						
		}
		if ( ErrorCount == 0 ) Print("[SEM] EWD check...OK");
		else Print("[SEM] EWD Check Summary: "+ ErrorCount +" missions have incorrect EventsWorldData. Check coordinates in debug mode!");	
	}
	
	static bool PrimaryMissionCHK( string type, vector position , int nr )
	{
		//List all mission types with no prim. MissionBuilding here!
		ref array<string> ExcludedTypes = new array<string>;
		ExcludedTypes.InsertArray( {"Camp","Shrooms","Graveyard","BearHunt","PlaneCrash","Horde"} );	
		string building;
		bool BuildingFound;
				
		for ( int i=0; i < ExcludedTypes.Count(); i++)	{ if ( type == ExcludedTypes.Get(i) ) return true;}
		
		//Add new mission type and building type for primary mission here!
		if ( type == "Apartment")					building = "Land_Tenement_Small";
		else if ( type == "CityMall")				building = "Land_City_Store";
		else if ( type == "FreePigs")				building = "Land_Farm_CowshedA";
		else if ( type == "Transport")				building = "Land_Garage_Row_Small";
		else 
		{
			Print("[SEM] EWD Check WARNING : Mission "+ nr +" - Mission type "+ type +" is undefined in EventsWorldData!");
			return false;
		}
				
		BuildingFound = false;
		
		GetGame().GetObjectsAtPosition( position, 1.0, ObjectList, ObjectCargoList);
		for ( int j=0; j < ObjectList.Count(); j++)
		{
			Object FoundObject = ObjectList.Get(j);
			if ( FoundObject.GetType() != building )
			continue;
			else 
			{
				BuildingFound = true;
				break;
			}						
		}
		if ( !BuildingFound ) 
		{
			Print("[SEM] EWD Check WARNING :: Mission "+ nr +" - Can't find "+ building +" @ "+ position );
			return false;		
		}
		else return true;		
	}	
	
	static bool SecondaryMissionCHK( string type, string location, int nr )
	{
		//List all mission types with no sec. MissionBuilding here!
		ref array<string> ExcludedTypes = new array<string>;
		ExcludedTypes.InsertArray( {"Apartment","Camp","Graveyard","PlaneCrash","Horde"} );
		
		ref array<vector> ExtendedPosList = new array<vector>;
		string building;
		bool BuildingFound;
		
		for ( int i=0; i < ExcludedTypes.Count(); i++)	{ if ( type == ExcludedTypes.Get(i) ) return true;}
		
		//Add new mission type and building type for secondary mission here!
		if ( type == "BearHunt")					building = "Land_City_School";
		else if ( type == "CityMall")				building = "Land_Village_PoliceStation";
		else if ( type == "FreePigs")				building = "Land_Misc_TrailRoof_Small";
		else if ( type == "Shrooms")				building = "Land_City_Hospital";
		else if ( type == "Transport")				building = "Land_FuelStation_Build";
		else
		{
			Print("[SEM] EWD Check WARNING :: Mission "+ nr +" - Mission type "+ type +" is undefined in EventsWorldData!");
			return false;
		}
		
		if ( GetBuildingsAtLoc( building, location, ExtendedPosList ))
		{
			for ( int k=0; k < ExtendedPosList.Count(); k++)
			{
				BuildingFound = false;
				
				vector pos = ExtendedPosList.Get(k);
				
				GetGame().GetObjectsAtPosition( pos, 1.0, ObjectList, ObjectCargoList);
				for ( int j=0; j < ObjectList.Count(); j++)
				{
					Object FoundObject = ObjectList.Get(j);
					if ( FoundObject.GetType() != building )
					continue;
					else 
					{
						BuildingFound = true;
						break;
					}							
				}
				if ( !BuildingFound ) 
				{
					Print("[SEMM] EWD Check WARNING :: Mission "+ nr +" - Can't check back "+ building +" at position: "+ pos );								
					return false;
				}
			}
			return true;			
		}
		else 
		{
			Print("[SEM] EWD Check WARNING :: Mission "+ nr +" - Can't check back "+ building +" at location: "+ location );
			return false;
		}
	}
	
	static void BuildStatics()
	{
		//add static buildings / objects here. This function must be activated in MissionSettings!

		//HQ world position and orientation (main building)
		vector HQCenterPOS = {-744, 34, 1016};
		vector HQCenterORI = {0, 0, 0};		//Set to {360,0,0} if u want a random orientation
		
		//HQ container
		ref array<ref Param3<string,vector,vector>> BuildingSpawns = new array<ref Param3<string,vector,vector>>;
		
		//Spawn main HQ building
		if ( HQCenterORI[0] == 360 ) HQCenterORI[0] = Math.RandomFloatInclusive(0,359.9);
		Object MainBuildingHQ = GetGame().CreateObject("Land_Mil_ATC_Big", HQCenterPOS );		
		MainBuildingHQ.SetOrientation( HQCenterORI );
		MainBuildingHQ.PlaceOnSurface();
		Print("[SEM] HQ :: Main building "+ MainBuildingHQ.GetType() +" spawned @"+ MainBuildingHQ.GetPosition() );
		
		//Spawn surrounding HQ buildings, ("Land_Sawmill_Illumnatnttower", "30 0 30", "x 0 0") -> x = Heading in ° (printed in debug mode!)
		BuildingSpawns.Insert( new Param3<string,vector,vector>("Land_Mil_Fortified_Nest_Watchtower", "30 0 30", "135 0 0"));
		BuildingSpawns.Insert( new Param3<string,vector,vector>("Land_Mil_Fortified_Nest_Watchtower", "-30 0 30", "225 0 0"));
		
		//Spawn HQ additional buildings
		for ( int i=0; i < BuildingSpawns.Count(); i++ )
		{
			Param3<string,vector,vector> BuildingDef = BuildingSpawns.Get(i);
			string BuildingType = BuildingDef.param1;
			vector BuildingPos = MainBuildingHQ.ModelToWorld( BuildingDef.param2 );
			vector BuildingOri = BuildingDef.param3;
			vector BuildingDir = MainBuildingHQ.GetDirection();
			
			Object HQextra = GetGame().CreateObject( BuildingType, BuildingPos );
			HQextra.SetPosition( BuildingPos );
			HQextra.SetDirection( BuildingDir );
			HQextra.SetOrientation( HQextra.GetOrientation() + BuildingOri );
			HQextra.PlaceOnSurface();
			Print("[SEM] HQ :: Additional building "+ HQextra.GetType() +" spawned @"+ HQextra.GetPosition() );
		}		
	}
	
	static void ShowDebugInfo( PlayerBase player)
	{
		//Display as server message to player: if found, Modelvector & buildingtype else actual position of player
		Param1<string> Msg1;
		ref array<Object> OBJLST1 = new array<Object>;
		ref array<CargoBase> PROXYLST1 = new array<CargoBase>;
			
		GetGame().GetObjectsAtPosition( player.GetPosition() , 30.0 , OBJLST1 , PROXYLST1 );		
		for ( int j = 0 ; j < OBJLST1.Count(); j++ )
		{ 
			Object FoundObject = OBJLST1.Get(j);
			if (FoundObject.GetType() == "Land_Medical_Tent_Big") 
			{
				Msg1 = new Param1<string> ("Medical_Tent_Big, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}
			else if (FoundObject.GetType() == "Land_City_School")
			{
				Msg1 = new Param1<string> ("City_School, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}			
			else if (FoundObject.GetType() == "Land_Farm_CowshedA")
			{
				Msg1 = new Param1<string> ("CowshedA, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}			
			else if (FoundObject.GetType() == "Land_Tenement_Small")
			{
				Msg1 = new Param1<string> ("Tenement_Small, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}			
			else if (FoundObject.GetType() == "Land_Tenement_Big")
			{
				Msg1 = new Param1<string> ("Tenement_Big, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}
			else if (FoundObject.GetType() == "Land_Garage_Row_Small")
			{
				Msg1 = new Param1<string> ("Garage_Row_Small, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}
			else if (FoundObject.GetType() == "Land_Garage_Row_Big")
			{
				Msg1 = new Param1<string> ("Garage_Row_Big, Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				break;
			}
			else if (FoundObject.GetType().Contains("Land_"))
			{
				Msg1 = new Param1<string> ( FoundObject.GetType() +", Pos.: " + FoundObject.GetPosition().ToString() + " Modelvector: " + (FoundObject.WorldToModel( player.GetPosition())).ToString());
				GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
				//break;
			}									
		}
		
		if ( j == OBJLST1.Count() )
		{
			Msg1 = new Param1<string> ("My position is: " + player.GetPosition().ToString() );
			GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
			
			vector ori = player.GetOrientation();
			float heading = ori[0];
			if ( heading < 0 ) heading += 360;
			
			Msg1 = new Param1<string> ("Heading: "+ heading.ToString() +"°" );
			GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());			
			j = 0;
		}
		
		if ( MissionSettings.Opt_RPmode )
		{
			Msg1 = new Param1<string> ("Actual RP mission is " + m_actualRPMission +". "+ m_MissionDescription[0] +" mission "+ m_MissionDescription[2] +" of "+ m_MissionDescription[1] +", extended: "+ m_MissionDescription[3]);
			GetGame().RPCSingleParam( player, ERPCs.RPC_USER_ACTION_MESSAGE, Msg1, true, player.GetIdentity());
		}			
	}
	
	static void RCMapByBuilding( string MBuilding )
	{
		//Runs a raycast from the middle of the map and prints all buildings of desired type 
		ref array<Object> Objects = new array<Object>;
		ref array<CargoBase> ObjectCargos = new array<CargoBase>;
		float vertex;
		vector Center = "7680 0 7680";		//Banov terrain center position
				
		if ( Center[0] < Center[2] ) vertex = Center[2];
		else vertex = Center[0];
		
		Print("[SEM] DEBUG MODE: Map wide raycast for:  "+ MBuilding );	
		
		float Rad = vertex * 1.414214;
				
		Print("[SEM] Map: "+ GetGame().GetWorldName() +" Center: "+ Center +", Radius: "+ Rad ); 
		 
		GetGame().GetObjectsAtPosition( Center, Rad, Objects, ObjectCargos );
		for ( int i=0; i < Objects.Count(); i++ )
		{
			Object FoundObject = Objects.Get(i);
			if ( FoundObject && FoundObject.GetType() == MBuilding )
			{
				Print("[SEM] Found building "+ MBuilding +" @ "+ FoundObject.GetPosition().ToString() );
			}
		}
		Print("[SEM] DEBUG MODE: Map wide raycast END");		
	}
}